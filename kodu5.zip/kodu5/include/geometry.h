#ifndef GEOMETRY_H
#define GEOMETRY_H

// Include own headers
// NB! Add your own headers here!
#include "point2.h"
#include "line2.h"
#include "circle2.h"


#endif // GEOMETRY_H
