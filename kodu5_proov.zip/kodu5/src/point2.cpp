#include "../include/point2.h"


Point2::Point2(float nx, float ny) : x {nx}, y {ny} {}

float Point2::distanceFrom (Point2 p) {
	// siia kood
	float arv = x + y;
	float arv2 = p.x * p.y;
	return arv + arv2;
}

// TODO: Operators...
