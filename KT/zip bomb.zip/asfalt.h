#ifndef ASFALT_H
#define ASFALT_H

#include <string>

std::string ajakulu(float meeter);
float teepikus(float laius, float liiter);
std::string arvuta_ajakulu(float laius, float liiter);

#endif